This model is pre-trained **XLNET** with 12 layers.

It comes with paper: SBERT-WK: A Sentence Embedding Method By Dissecting BERT-based Word Models

Project Page: [SBERT-WK](https://github.com/BinWang28/SBERT-WK-Sentence-Embedding)
